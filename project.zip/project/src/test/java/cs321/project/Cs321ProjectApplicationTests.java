package cs321.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs321ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
